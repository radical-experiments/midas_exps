#!/bin/bash
#----------------------------------------------------
# Example SLURM job script to run OpenMP applications
# on TACC's Stampede system.
#----------------------------------------------------
#SBATCH -J cpptraj_en_1_1  # Job name
#SBATCH -o cpptraj_en_1_1.out   # Name of stdout output file(%j expands to jobId)
#SBATCH -e cpptraj_en_1_1.err   # Name of stderr output file(%j expands to jobId)
#SBATCH -p normal
#SBATCH -N 1                # Total number of nodes requested (16 cores/node)
#SBATCH -n 1                # Total number of mpi tasks requested
#SBATCH -t 00:30:00         # Run time (hh:mm:ss) - 1.5 hours
# The next line is required if the user has more than one project
#SBATCH -A TG-MCB090174  # Allocation name to charge job against
#SBATCH --mail-user=i.paraskev@rutgers.edu
#SBATCH --mail-type=begin  # email me when the job starts
#SBATCH --mail-type=end    # email me when the job finishes

# This example will run an OpenMP application using 16 threads
module load netcdf
module load pnetcdf
module load remora

export REMORA_PERIOD=1

cd /scratch/03170/tg824689/cpptraj_exp/x2_2/1_1
remora /home1/00301/tg455746/GitHub/cpptraj/bin/cpptraj -i cpptraj_ens.in


